import os
import spacy
from spacy import displacy
import warnings
warnings.filterwarnings("ignore")


def ner_visualize():
    nlp = spacy.load("en_core_web_sm")

    # 업로드 파일 받아오기
    a = os.listdir("./upload_files")

    text = open('./upload_files/{}'.format(a[0]), mode='rt', encoding='utf-8')
    text = text.read()

    doc = nlp(text)
    html = displacy.render(doc, style="ent", page=False)

    with open('templates/NERPage.html', 'a') as html_file:
        html_file.write(html)

