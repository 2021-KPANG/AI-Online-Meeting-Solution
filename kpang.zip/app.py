import warnings
from flask import Flask, render_template, request, redirect, url_for
from ner import ner_visualize
from werkzeug.utils import secure_filename
from summarizer import Summarizer
import os

warnings.filterwarnings("ignore")
app = Flask(__name__)

@app.route("/", methods=['GET', 'POST'])
def start_page():
    file = 'templates/NERPage.html'
    if os.path.isfile(file):
        os.remove(file)

    return render_template('StartPage.html')



@app.route("/page1", methods=['GET', 'POST'])
def html_page():

    if request.method == 'POST':
        f = request.files['file']
        f.save('./upload_files/' + secure_filename(f.filename))

    return render_template('HTMLPage1.html')


@app.route("/OriginPage")
def origin():

    # 업로드 파일 받아오기
    a = os.listdir("./upload_files")

    text = open('./upload_files/{}'.format(a[0]), mode='rt', encoding='utf-8')
    text = text.read()

    return render_template('OriginPage.html', data=text)


@app.route("/SummaryPage")
def summary():

    # 업로드 파일 받아오기
    a = os.listdir("./upload_files")

    # 텍스트 변수에 받아오기
    text = open('./upload_files/{}'.format(a[0]), mode='rt', encoding='utf-8')
    text = text.read()
    model = Summarizer('distilbert-base-uncased')
    resp = model(text)

    return render_template('SummaryPage.html', data=resp)


@app.route("/NERPage")
def ner():
    ner_visualize()
    return render_template('NERPage.html')


if __name__ == "__main__":
    app.run()

